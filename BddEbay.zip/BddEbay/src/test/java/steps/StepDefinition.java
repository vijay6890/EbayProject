package steps;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterMethod;

import io.cucumber.java.en.And;
import io.cucumber.java.en.But;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class StepDefinition {

	public ChromeDriver driver;
	
	@Given("Open the Chrome browser")
	public void openBrowser() {

		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	}

	@And("Load the ebay application url {string}")
	public void loadURL(String url) {
		driver.get(url);
	}

	@And("Input the keyword {string} in search field")
	public void searchBike(String searchtext) {
		driver.findElement(By.xpath("//*[@id=\"gh-ac\"]")).sendKeys(searchtext, Keys.ENTER);
	}

	@And("Click and select the first bike from the search results")
	public void selectBike() {
		driver.findElement(By.xpath("(//h3[@class='s-item__title s-item__title--has-tags'])[2]")).click();
	}

	@And("Navigate to My Ebay Summary")
	public void ebaySummary() {
		WebElement summary = driver.findElement(By.xpath("//a[@class='gh-eb-li-a gh-rvi-menu']"));
		Actions actions = new Actions(driver);
		actions.moveToElement(summary).perform();
		driver.findElement(By.xpath("//a[@class='gh-eb-oa thrd']")).click();
	}

	@When("User clicks continue buttons without filling the username")
	public void continueClick() {
		driver.findElement(By.id("signin-continue-btn")).click();
	}

	@When("Click on Add to cart and goto to Cart")
	public void addCart() {
		Set<String> winSet = driver.getWindowHandles();
		List<String> winList = new ArrayList<String>(winSet);
		driver.switchTo().window(winList.get(1));
		// Select se = new Select(driver.findElement(By.name("Colour")));
		// se.selectByValue("0");
		driver.findElement(By.linkText("Add to cart")).click();
	}

	@But("Error message should be displayed")
	public void errorValidation() {
		try {
			driver.findElement(By.id("signin-continue-btn")).click();

			// Thread.sleep(3000);
			String errortext = driver.findElement(By.xpath("//p[@id='errormsg']")).getText();

			if (errortext.equalsIgnoreCase("Oops, that's not a match.")) {
				System.out.println("Test Passed, Error text has been verifed and the text is: " + errortext);
			} else {
				System.out.println("No error text received and test failed");
			}
		} catch (Exception e) {
			System.out.println(
					"There is a Captcha; Please handle the captcha manually once to overcome this no such element exception");
			System.out.println();
			System.out.println(e);
		}
		driver.quit();
	}

	@Then("Verify the added bike details are displaying to the user")
	public void gotoCart() {
		driver.findElement(By.xpath("//a[contains(@class,'btn btn-scnd')]")).click();
		String text = driver.findElement(By.className("BOLD")).getText();
		if (text.contains("NORFLEX 26")) {

			System.out.println(text);
			System.out.println("Bike matched, Test Pass");
		} else {
			System.out.println("Bike is not matched, Test Fail");
		}
		driver.quit();
	}

}
